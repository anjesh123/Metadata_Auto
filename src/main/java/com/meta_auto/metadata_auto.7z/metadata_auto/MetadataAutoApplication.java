package com.meta_auto.metadata_auto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetadataAutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetadataAutoApplication.class, args);
	}

}
