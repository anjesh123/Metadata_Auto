package com.meta_auto.metadata_auto.dao;

public class APIDisplayConfig {
      private ArrayList<rows> r[];
      private String DBLabel;
      private String transferFielfKey;
      private ArrayList<sourceApi> sapi[];
      private ArrayList<displayitem> ditm[];
      private boolean TestConfiguration;
      private ArrayList<TestApi> tapi[];
      
      
}
