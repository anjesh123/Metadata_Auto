package com.meta_auto.metadata_auto.dao;

public class Input {
  private String hint; 
  private String name;
  private String placeholder;
  private String type;
  private ArrayList<Validations> val[];
  
}
