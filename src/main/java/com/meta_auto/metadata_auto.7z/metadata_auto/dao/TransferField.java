package com.meta_auto.metadata_auto.dao;

public class TransferField {
    private string key;
    private string/obj value;
}
