package com.meta_auto.metadata_auto.dao;

public class meta_dao {
   private String id;
   private String name;
   private String iname;
   private int version ;
   private ArrayList<TransferField> etf[];
   private ArrayList<Section> sec[];
   
   
}
