package com.meta_auto.metadata_auto.dao;

public class sourceApi {
 private String Path;
 private String authType;
 private String idField;
 private String labelFields;
 
}
